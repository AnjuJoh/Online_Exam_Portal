import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  userObject =
  {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: {
      roleName: '',
      id: '',
    }
  } ;
loggedIn : any;
  constructor(private authService:AuthService,) { }

  ngOnInit(): void {
    var user = localStorage.getItem('currentUser');

    this.userObject = user != null ? JSON.parse(user) : this.userObject;

if (user != '') {
  this.loggedIn = true;
} else {
  this.loggedIn = false;

}

  }

}
