import { HttpClient } from '@angular/common/http';
import { Component, HostListener, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { OrderServiceService } from 'src/app/services/order-service.service';
import { QuizService } from 'src/app/services/quiz.service';
declare var Razorpay:any;
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  userName:string ='';
  password:string = '';
  payment:string='';
  





  user=
    {
      email:'',
      password: '',
      firstName: '',
      lastName: '',
      phone: '',
      enabled: true,
      role : {
        id : '',
        roleName: ''
      }
    }
  ;
  title = 'demo';
  quizzes:any;
  message:any = "Not yet started";
  paymentId = "";
  error = "";
  options = {
    "key": "",
    "amount": "200",
    "name": "",
    "description": "",
    "order_id": "",
    "handler": function (response: any) {
      var event = new CustomEvent("payment.success",
        {
          detail: response,
          bubbles: true,
          cancelable: true
        }
      );
      window.dispatchEvent(event);
    },
    "prefill": {
      "name": "",
      "email": "",
      "contact": ""
    },
    "notes": {
      "address": ""
    },
    "theme": {
      "color": "#3399cc"
    }
  };

  paynow() {
    this.paymentId = '';
    this.error = '';
    this.options.amount = "200"; //paise
    this.options.prefill.name = "";
    this.options.prefill.email = "";
    this.options.prefill.contact = "";
    var rzp1 = new Razorpay(this.options);
    rzp1.open();
    rzp1.on('payment.failed', function (response: any) {
      //this.message = "Payment Failed";
      // Todo - store this information in the server
      console.log(response.error.code);
      console.log(response.error.description);
      console.log(response.error.source);
      console.log(response.error.step);
      console.log(response.error.reason);
      console.log(response.error.metadata.order_id);
      console.log(response.error.metadata.payment_id);
      //this.error = response.error.reason;
    }
    );
  }
  @HostListener('window:payment.success', ['$event'])
  onPaymentSuccess(event: any): void {
    this.message = "Success Payment";
  }

  form: any = {}; 
    qid: any;
    quiz:any;
    amount:any;
   
  constructor(private http: HttpClient,
    private orderService:OrderServiceService,
    private authService:AuthService,
    private snack:MatSnackBar
    // private _route: ActivatedRoute,
    // private _quiz: QuizService,
    // private _router: Router
    ) {

  }

  ngOnInit() {
    // this.qid = this._route.snapshot.params['qId'];
    // console.log(this.qid);

    // this._quiz.getQuiz(this.qid).subscribe(
    //   (data: any) => {
    //     // console.log(data);
    //     this.quiz = data;
    //   },
    //   (error) => {
    //     console.log(error);
    //     alert('Error in loading quiz data');
    //   }

    // );
  }

  // sayHello() {
  //   alert("Hello DK");
  // }

  // paymentId: any;
  // error: any;


  // options = {
  //   "key": "",
  //   "amount": "", 
  //   "name": "",
  //   "description": "",
  //   "image": "https://www.javachinna.com/wp-content/uploads/2020/02/android-chrome-512x512-1.png",
  //   "order_id":"",
  //   "handler": function (response: any){
  //     var event = new CustomEvent("payment.success", 
  //       {
  //         detail: response,
  //         bubbles: true,
  //         cancelable: true
  //       }
  //     );	  
  //     window.dispatchEvent(event);
  //   }
  //   ,
  //   "prefill": {
  //   "name": "",
  //   "email": "",
  //   "contact": ""
  //   },
  //   "notes": {
  //   "address": ""
  //   },
  //   "theme": {
  //   "color": "#3399cc"
  //   }
  //   };

  //   onSubmit(): void {
  //     this.paymentId = ''; 
  //     this.error = ''; 
  //     this.orderService.createOrder(this.amount).subscribe(
  //     (data:any) => {
  //       this.options.key = data.secretId;
  //       this.options.order_id = data.razorpayOrderId;
  //       this.options.amount = data.applicationFee; //paise
  //       this.options.prefill.name = "";
  //       this.options.prefill.email = "";
  //       this.options.prefill.contact = "";

  //       if(data.pgName ==='razor2') {
  //         this.options.image="";
  //         var rzp1 = new Razorpay(this.options);
  //         rzp1.open();
  //       } else {
  //         var rzp2 = new Razorpay(this.options);
  //         rzp2.open();
  //       }


  //       rzp1.on('payment.failed',  (response:any) =>{    
  //         // Todo - store this information in the server
  //         console.log(response);
  //         console.log(response.error.code);    
  //         console.log(response.error.description);    
  //         console.log(response.error.source);    
  //         console.log(response.error.step);    
  //         console.log(response.error.reason);    
  //         console.log(response.error.metadata.order_id);    
  //         console.log(response.error.metadata.payment_id);
  //         this.error = response.error.reason;
  //       }
  //       );
  //     }
  //     ,
  //     (err:any) => {
  //       this.error = err.error.message;
  //     }
  //     );
  //   }

  //   @HostListener('window:payment.success', ['$event']) 
  //   onPaymentSuccess(event:any): void {
  //      console.log(event.detail);
  //   }


paymentStart() {
  console.log(this.userName,this.password);

  if (this.userName.trim() == '' || this.userName == null) {
    this.snack.open('UserName is required!!','',{
      duration:3000,
    });
  }
  if (this.password.trim() == '' || this.password == null) {
    this.snack.open('Password is required!!','',{
      duration:3000,
    });
  }

  this.authService.authenticateUser(this.userName,this.password).subscribe((data:any) => {
    this.user = data;
    let amount="350";
    if((this.user)){
      console.log("payment started..");
      console.log(this.payment);

    };
  

  });

}
}

