package com.exam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.model.User;
import com.exam.model.exam.Quiz;
import com.exam.service.impl.UserServiceImpl;


@RestController
@CrossOrigin("*")
public class UserController {
	

	@Autowired
	UserServiceImpl userServiceImpl;
	
	
	@PostMapping("/api/registerUser")
	public User registerUser(@RequestBody User user) throws Exception {
		return userServiceImpl.registerUser(user);
	}
	
	@GetMapping("/api/getUsers")
	public ResponseEntity<List<User>> getAllUsers() throws Exception {
		return ResponseEntity.ok(this.userServiceImpl.getUsers());
		
	}
	
	@GetMapping("/api/getUser/{id}")
	public User getUser(@PathVariable("id") Long id) throws Exception {
		return this.userServiceImpl.getUser(id);
	}
//	
	@PutMapping("/api/updateUser")
	public ResponseEntity<?> updateUser(@RequestBody User user) throws Exception{
		return ResponseEntity.ok(this.userServiceImpl.updateUser(user));
	}

//	get quiz
//	@GetMapping("/")
//	public ResponseEntity<?> quizzes(){
//		return ResponseEntity.ok(this.quizService.getQuizzes());
//	}
}
