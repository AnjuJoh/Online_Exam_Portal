package com.exam.service;

public interface AuthenticationService {
	
	public boolean authenticateUser(String username, String password);

}
