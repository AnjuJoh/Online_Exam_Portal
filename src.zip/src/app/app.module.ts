import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { LoginComponent } from './pages/login/login.component';
import {MatInputModule} from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatButtonModule} from '@angular/material/button';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from  '@angular/common/http';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import {MatCardModule} from '@angular/material/card';
import { Routes } from '@angular/router';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { ProfileComponent } from './pages/examiner/profile/profile.component';
import { ExaminerComponent } from './pages/examiner/examiner.component';
import { DashboardComponent } from './pages/examiner/dashboard/dashboard.component';
import {MatListModule} from '@angular/material/list';
import { SidebarComponent } from './pages/examiner/sidebar/sidebar.component';
import { ExaminerpanelComponent } from './pages/examiner/examinerpanel/examinerpanel.component';
import { ViewCategoriesComponent } from './pages/examiner/view-categories/view-categories.component';
import { AddCategoryComponent } from './pages/examiner/add-category/add-category.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { ViewQuizzesComponent } from './pages/examiner/view-quizzes/view-quizzes.component';
import { AddQuizComponent } from './pages/examiner/add-quiz/add-quiz.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import { UpdateQuizComponent } from './pages/examiner/update-quiz/update-quiz.component';
import { ViewQuizQuestionsComponent } from './pages/examiner/view-quiz-questions/view-quiz-questions.component';
import { AddQuestionComponent } from './pages/examiner/add-question/add-question.component';
import { UserComponent } from './pages/examiner/user/user.component';
import { UserDashboardComponent } from './pages/user/user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './pages/examiner/admin-dashboard/admin-dashboard.component';
import { AdminSidebarComponent } from './pages/examiner/admin-sidebar/admin-sidebar.component';
import { ViewRoleComponent } from './pages/examiner/view-role/view-role.component';
import { AddRoleComponent } from './pages/examiner/add-role/add-role.component';
import { AddUserComponent } from './pages/examiner/add-user/add-user.component';
import { UserSidebarComponent } from './pages/user/user-sidebar/user-sidebar.component';
import { LoadQuizComponent } from './pages/user/load-quiz/load-quiz.component';
import { InstructionsComponent } from './pages/user/instructions/instructions.component';
import { StartComponent } from './pages/user/start/start.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';



const routes: Routes=[
  {path : 'login',component:LoginComponent}
];


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    RegistrationComponent,
    LoginComponent,
    HeaderComponent,
    HomeComponent,
    ProfileComponent,
    ExaminerComponent,
    DashboardComponent,
    SidebarComponent,
    ExaminerpanelComponent,
    ViewCategoriesComponent,
    AddCategoryComponent,
    ViewQuizzesComponent,
    AddQuizComponent,
    UpdateQuizComponent,
    ViewQuizQuestionsComponent,
    AddQuestionComponent,
    UserComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    AdminSidebarComponent,
    ViewRoleComponent,
    AddRoleComponent,
    AddUserComponent,
    UserSidebarComponent,
    LoadQuizComponent,
    InstructionsComponent,
    StartComponent   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatButtonModule,
    FormsModule,
    HttpClientModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatSnackBarModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatProgressSpinnerModule
    
    
  
  
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
