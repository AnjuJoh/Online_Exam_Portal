import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isAuthenticated=false;
  constructor(private http: HttpClient) { }

  public authenticateUser(userName : any,password : any) {

    console.log(userName,password);
   

    return this.http.get(`${baseUrl}/api/authenticateUser/${userName}/${password}`);

  }
}
