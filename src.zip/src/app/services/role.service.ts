import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private http: HttpClient) { }


  public addRole(role: any) {
    console.log('service', role)
    return this.http.post(`${baseUrl}/api/saveRole`, role);
  }

  public getAllRoles(){
    return this.http.get(`${baseUrl}/api/getRoles`);
  }

  public getRole(id: any) {
    return this.http.get(`${baseUrl}/api/getRole/${id}`);
  }

  public deletRole(id: any) {
    return this.http.delete(`${baseUrl}/api/deleteRole/${id}`);
  }
}
