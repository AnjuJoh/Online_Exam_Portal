import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  public registerUser(user: any) {
    console.log('service', user)
    return this.http.post(`${baseUrl}/api/registerUser`, user);
  }

  public getUser(id: any) {
    return this.http.get(`${baseUrl}/api/getUser/${id}`);
  }
  public getAllUsers() {
    return this.http.get(`${baseUrl}/api/getUsers`);
  }
  public addUsers() {
    return this.http.get(`${baseUrl}/api/addUser`);

  }


  public updateUser(item: any) {
    return this.http.put(`${baseUrl}/api/updateUser`, item)
  }
  // public deleteUsers(){
  //   return this.http.delete(`${baseUrl}/api/deleteUsers`);
  // }
  // public userRole(quiz:any){
  //   return this.http.get(`${baseUrl}/examiner`);
  // }
  // public addQuiz(quiz:any){
  //   console.log(quiz);
  //   return this._http.post(`${baseUrl}/quiz/`,quiz);
  // }

  // public deleteQuiz(qid: any){

  //   return this._http.delete(`${baseUrl}/quiz/${qid}`);
  // }

  // public getQuiz(qid:any){
  //   return this._http.get(`${baseUrl}/quiz/${qid}`);
  // }

  // public updateQuiz(quiz: any){
  //   return this._http.put(`${baseUrl}/quiz/`,quiz)
  // }

}
