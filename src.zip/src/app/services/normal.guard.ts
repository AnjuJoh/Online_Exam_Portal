import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class NormalGuard implements CanActivate {
    userObject =
  {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: {
      roleName: '',
      id: '',
    }
  } ;
  constructor(private authService: AuthService, private router: Router) {}

  
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
        var user = localStorage.getItem('currentUser');
        this.userObject = user != null ? JSON.parse(user) : this.userObject;
    // if (this.authService.isLoggedIn() && this.authService.getUserRole() == 'NORMAL') {
    //   return true;
    // }
    if (this.userObject.role.roleName == 'NORMAL') {
        return true;
    }

    this.router.navigate(['login']);
    return false;
  }
}