import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ModelTraining } from '@mui/icons-material';
import { map } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import baseUrl from 'src/app/services/helper';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName:string ='';
  password:string = '';


  user=
    {
      email:'',
      password: '',
      firstName: '',
      lastName: '',
      phone: '',
      enabled: true,
      role : {
        id : '',
        roleName: ''
      }
    }
  ;
  

  constructor(
    private authService:AuthService,
    private snack:MatSnackBar,
    private router : Router

  ){}


  ngOnInit(): void {
    localStorage.setItem('currentUser', '');
  }

  onSubmit() {
    console.log(this.userName,this.password);

    if (this.userName.trim() == '' || this.userName == null) {
      this.snack.open('UserName is required!!','',{
        duration:3000,
      });
    }
    if (this.password.trim() == '' || this.password == null) {
      this.snack.open('Password is required!!','',{
        duration:3000,
      });
    }

    this.authService.authenticateUser(this.userName,this.password).subscribe((data:any) => {
      this.user = data;
      localStorage.setItem('currentUser', JSON.stringify(this.user));
      
      if (this.user.role.roleName == 'ADMIN') {
        //ADmin dshbrd
        // window.location.href = '/admin';
        this.router.navigate(['admin/profile'])
      } else if (this.user.role.roleName == 'NORMAL') {
        // window.location.href = '/user-dashboard';
        this.router.navigate(['user-dashboard/0'])
      } else {
        this.router.navigate(['examiner/profile'])
      }
    }, 
      // if (result.)

      (error)=>{
        console.log(error);
        this.snack.open('Invalid details !! Try again','',{
          duration:3000
        });
      })

    };


  
  
}
