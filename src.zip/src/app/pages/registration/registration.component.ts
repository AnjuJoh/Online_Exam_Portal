import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {


  constructor(private userService: UserService,private _snack:MatSnackBar) { }


  public user = {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',

  };
 isValidFormSubmitted = false; 

  ngOnInit(): void {
  }

  // registerUser(){

  //   if(this.user.userName.trim()=='' || this.user.userName==null)
  //   {
  //     this._snack.open('UserName is required!!','',{
  //       duration:3000,
  //     });
  //     return;
  //   }

  //   if(this.user.password.trim()=='' || this.user.password==null)
  //   {
  //     this._snack.open('Password is required!!','',{
  //       duration:3000,
  //     });
  //     return;
  //   }
  //   if(this.user.firstName.trim()=='' || this.user.firstName==null)
  //   {
  //     this._snack.open('First Name is required!!','',{
  //       duration:3000,
  //     });
  //     return;
  //   }
  //   if(this.user.lastName.trim()=='' || this.user.lastName==null)
  //   {
  //     this._snack.open('Last Name is required!!','',{
  //       duration:3000,
  //     });
  //     return;
  //   }
  //   if(this.user.email.trim()=='' || this.user.email==null)
  //   {
  //     this._snack.open('Email is required!!','',{
  //       duration:3000,
  //     });
  //     return;
  //   }
  //   if(this.user.phone.trim()=='' || this.user.phone==null)
  //   {
  //     this._snack.open('Phone Number is required!!','',{
  //       duration:3000
  //     });
  //     return;
  //   }

    

  // }
   
  formSubmit(form: NgForm) {  
   this.isValidFormSubmitted = false;  
   console.log(form);

    
   if (form.invalid) {  
      return;  
   } 
 
   this.isValidFormSubmitted = true;
  

       this.userService.registerUser(this.user).subscribe(data => {

      console.log(data)
      this._snack.open("Registration Success",'',{
        panelClass:['green-snackbar'],
        duration:3000
      });
    },
      (error) => {
        console.log(error)
        this._snack.open("Something went wrong",'',{
          duration:3000
        });
      }
    )
   form.resetForm();  
}  
}  
  // formSubmit() {
  //   console.log(this.user);

  //   if (this.user.userName == '' || this.user.userName == null) {
  //     alert('UserName is required!!');
  //   }

  //   this.userService.registerUser(this.user).subscribe(data => {

  //     console.log(data)
  //     alert("Registration Success")
  //   },
  //     (error) => {
  //       console.log(error)
  //       alert("Something went wrong")
  //     }
  //   )

//   }

// }
