import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { RoleService } from 'src/app/services/role.service';

@Component({
  selector: 'app-view-role',
  templateUrl: './view-role.component.html',
  styleUrls: ['./view-role.component.css']
})
export class ViewRoleComponent implements OnInit {

  roles = [
    {
      id: '',
      roleName: '',

    }];

  constructor(private roleService: RoleService, private _snack: MatSnackBar, private router: Router) { }

  HeadArray = [
    { 'Head': 'Role Name', FieldName: 'roleName' },
    { 'Head': 'Action', FieldName: '' }
  ];

  ngOnInit(): void {
    this.getAllRole();
  }

  getAllRole() {
    this.roleService.getAllRoles().subscribe(
      (data: any) => {
        this.roles = data;
        console.log(this.roles);
      },
      (error) => {
        console.log(error);
        alert('Error!! Something went wrong');

      }
    );
  }

  delete(id: any) {
    console.log(id);
    this.roleService.deletRole(id).subscribe(
      (data: any) => {
        
      this.getAllRole();
      
      },
      (error) => {

        this._snack.open("Role cannot be deleted as this role is mapped to a user", '', {
          duration: 3000
        });
      }

    );

  }
  add() {
    console.log('add');
    this.router.navigate(['admin/addRole']);
  }

}
