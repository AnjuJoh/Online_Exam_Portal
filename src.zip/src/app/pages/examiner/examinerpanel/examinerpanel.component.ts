import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examinerpanel',
  templateUrl: './examinerpanel.component.html',
  styleUrls: ['./examinerpanel.component.css']
})
export class ExaminerpanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
