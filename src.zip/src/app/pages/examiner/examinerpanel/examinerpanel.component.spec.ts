import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExaminerpanelComponent } from './examinerpanel.component';

describe('ExaminerpanelComponent', () => {
  let component: ExaminerpanelComponent;
  let fixture: ComponentFixture<ExaminerpanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExaminerpanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExaminerpanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
