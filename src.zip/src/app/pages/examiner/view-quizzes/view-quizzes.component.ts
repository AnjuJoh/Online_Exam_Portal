import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Quiz } from '@mui/icons-material';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-view-quizzes',
  templateUrl: './view-quizzes.component.html',
  styleUrls: ['./view-quizzes.component.css']
})
export class ViewQuizzesComponent implements OnInit {

  quizzes = [
    {
      qid: '',
      title: '',
      description: '',
      maxMarks: '',
      numberOfQuestions: '',
      active: '',
      category: {
        title: ''
      }
    }];
  userObject =
    {
      userName: '',
      password: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      role: {
        roleName: '',
        id: '',
      }
    };

  constructor(private _quiz: QuizService, private _snack: MatSnackBar, private router: Router) { }

  ngOnInit(): void {
    var user = localStorage.getItem('currentUser');
    this.userObject = user != null ? JSON.parse(user) : this.userObject;
    this._quiz.quizzes().subscribe(
      (data: any) => {
        this.quizzes = data;
        console.log(this.quizzes);
      },
      (error) => {
        console.log(error);
        alert('Error!! Something went wrong');

      }
    );
  }

  deleteQuiz(qid: any) {
    this._quiz.deleteQuiz(qid).subscribe((data) => {
      this.quizzes = this.quizzes.filter((Quiz) => Quiz.qid != qid);

      this._snack.open('Success !! Quiz is deleted', '', {
        duration: 3000
      });
    }, (error) => {
      this._snack.open('Error in deleting quiz!!', '', {
        duration: 3000
      });
    }
    );

  }

  viewQuestions(qid: any, qTitle: any) {

    if (this.userObject.role.roleName == 'ADMIN') {
      this.router.navigate(['/admin/view-questions/' + qid + '/' + qTitle])
    } else {
      this.router.navigate(['/examiner/view-questions/' + qid + '/' + qTitle])
    }
  }
  addNewQuiz() {

    if (this.userObject.role.roleName == 'ADMIN') {
      this.router.navigate(['/admin/add-quiz/'])
    } else {
      this.router.navigate(['/examiner/add-quiz/'])
    }
  }

  updateQuestions(qid:any) {

    if (this.userObject.role.roleName == 'ADMIN') {
      this.router.navigate(['/admin/quiz/'+ qid])
    } else {
      this.router.navigate(['/examiner/quiz/'+ qid])
    }
  }

}
