import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { SystemSecurityUpdate } from '@mui/icons-material';
import { RoleService } from 'src/app/services/role.service';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit {

  id = 0;

  role = {
    roleName: '',
    id: ''
  }

  constructor(private _route: ActivatedRoute, private roleService: RoleService, private _snack: MatSnackBar, private router: Router) { }

  ngOnInit(): void {

    this.id = this._route.snapshot.params['id'];
    console.log('this.id', this.id)

    if (this.id != undefined) {

      this.roleService.getRole(this.id).subscribe(
        (data: any) => {
          this.role = data;
          console.log(this.role);
        },
        (error) => {
          console.log(error);

        }
      );
    }
  }

  addRole() {
    this.roleService.addRole(this.role).subscribe(
      (data: any) => {
        this.role = data;
        console.log(this.role);
        this.router.navigate(['admin/role']);
      },
      (error) => {
        console.log(error);

        this._snack.open("Failed to Create New Role", '', {
          duration: 30
        });
      }
    );
  }

  // updateRole() {
  //   this.roleService.updateRole(this.role).subscribe(
  //     (data: any) => {
  //       this.role = data;
  //       console.log(this.role);
  //     },
  //     (error) => {
  //       console.log(error);

  //       this._snack.open("Failed to Create New User", '', {
  //         duration: 30
  //       });
  //     }
  //   );
  // }

}
