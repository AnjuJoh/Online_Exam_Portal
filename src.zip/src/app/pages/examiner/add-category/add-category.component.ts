import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SwapCalls } from '@mui/icons-material';
import { CategoryService } from 'src/app/services/category.service';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {

  category={
    title:'',
    description:'',
    user :
    {
      userName: '',
      password: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      role: {
        roleName: '',
        id: ''
      }
    }
  };

  userObject =
  {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: {
      roleName: '',
      id: '',
    }
  } ;

  constructor(private _category:CategoryService,private _snack:MatSnackBar) { }

  ngOnInit(): void {
  }
  formSubmit(){
    
    if(this.category.title.trim()=='' || this.category.title==null)
    {
      this._snack.open("Title Required !!",'',{
        duration:3000,
      });
      return;
    }
    var user = localStorage.getItem('currentUser');
    console.log(user)
    this.category.user = user !== null ? JSON.parse(user) : this.userObject;
    this._category.addCategory(this.category).subscribe(
      (data:any)=>{
        this.category.title='';
        this.category.description='';
        this._snack.open('Success !! New Category is added','',{
          duration:3000,
        });
      },
      (error)=>{
        console.log(error);
        alert('Error!! Something went wrong');
      }
    );

  }


}
