import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionService } from 'src/app/services/question.service';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {

  qId: any;

  qTitle:any;
  
  question={
    quiz:{
      qid : '',
    },
    content:'',
    option1:'',
    option2:'',
    option3:'',
    option4:'',
    answer:'',
  };

  constructor(private _route:ActivatedRoute,private _question:QuestionService) { }

  ngOnInit(): void {

    this.qId=this._route.snapshot.params['qid'];
    this.qTitle=this._route.snapshot.params['title'];
    this.question.quiz['qid']=this.qId;
    console.log('this.qId:',this.qId);
    console.log('this.qTitle:',this.qTitle);
    console.log('this.question.quiz:',this.question.quiz);
  }

  formSubmit(){
    if(this.question.content.trim()=='' || this.question.content == null){
      return;
    }
    if(this.question.option1.trim()=='' || this.question.option1 == null){
      return;
    }
    if(this.question.option2.trim()=='' || this.question.option2 == null){
      return;
    }
    if(this.question.option3.trim()=='' || this.question.option3 == null){
      return;
    }
    if(this.question.option4.trim()=='' || this.question.option4 == null){
      return;
    }

    this._question.addQuestion(this.question).subscribe((data:any)=>{
      alert('Success!! Question is added');
      console.log(data);
    },
    (error)=>{
      alert('Error in adding question')
      console.log(error);
    })

  }

}
