import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examiner',
  templateUrl: './examiner.component.html',
  styleUrls: ['./examiner.component.css']
})
export class ExaminerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
