import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CategoryService } from 'src/app/services/category.service';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-add-quiz',
  templateUrl: './add-quiz.component.html',
  styleUrls: ['./add-quiz.component.css']
})
export class AddQuizComponent implements OnInit {


  categories=[
    {
      cid:'',
      title:'',
    }
  ];
  

  quizData={
    title:'',
    description:'',
    maxMarks:'',
    numberOfQuestions:'',
    active: true,
    category: {
      cid:'',
    },
  };
isValidFormSubmitted: any;

  constructor(private _cat:CategoryService,private _snack:MatSnackBar,private quizService:QuizService) { }

  ngOnInit(): void {

    this._cat.categories().subscribe(
      (data: any)=>{
        console.log('data',data);
        this.categories=data;
        // console.log(this.categories);

      },
      (error)=>{
      console.log(error);
      alert('Error!! Something went wrong');
      }
    );
  }
  // formSubmit(form : NgForm) {
  //   console.log(this.quizData);
  //   if(this.quizData.title.trim()=='' || this.quizData.title==null)
  //   {

  //     this._snack.open('Title Required!!','',{
  //       duration:3000,
  //     });
  //     return;

  //   }
  formSubmit(form: NgForm) {  
   this.isValidFormSubmitted = false;
   this._snack.open('Invalid details!!','',{
    duration:3000,
   })  
   console.log(form);

    
   if (form.invalid) {  
      return;  
   } 
 
   this.isValidFormSubmitted = true;
    this.quizService.addQuiz(this.quizData).subscribe(
      (data: any)=>{
        this._snack.open('Success!! Quiz is added','',{
          duration:3000,
        });
        this.quizData={
          title:'',
          description:'',
          maxMarks:'',
          numberOfQuestions:'',
          active: true,
          category: {
            cid:'',
          },
        };
      },
      (error: any)=>{
        console.log(error);
        alert('Error Occured while adding quiz!!');
      }
    );
    }

  // addQuiz(){
  //   if(this.quizData.title.trim()=='' || this.quizData.title==null)
  //   {

  //     this._snack.open('Title Required!!','',{
  //       duration:3000,
  //     });
  //     return;

  //   }
  //   this.quizService.addQuiz(this.quizData).subscribe(
  //     (data: any)=>{
  //       this._snack.open('Success!! Quiz is added','',{
  //         duration:3000,
  //       });
  //       this.quizData={
  //         title:'',
  //         description:'',
  //         maxMarks:'',
  //         numberOfQuestions:'',
  //         active: true,
  //         category: {
  //           cid:'',
  //         },
  //       };
  //     },
  //     (error: any)=>{
  //       console.log(error);
  //       alert('Error Occured while adding quiz!!');
  //     }
  //   );
  // }

}
