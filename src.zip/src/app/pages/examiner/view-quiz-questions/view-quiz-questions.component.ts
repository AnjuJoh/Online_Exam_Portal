import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-view-quiz-questions',
  templateUrl: './view-quiz-questions.component.html',
  styleUrls: ['./view-quiz-questions.component.css']
})
export class ViewQuizQuestionsComponent implements OnInit {


  qId: any;
  qTitle: any;

  question=[
    {
      quesId:'',
      content:'',
      option1:'',
      option2:'',
      option3:'',
      option4:'',
      answer:'',
    }
  ];
   userObject =
  {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: {
      roleName: '',
      id: '',
    }
  } ;

  constructor(

    private _route:ActivatedRoute,
    private _question:QuestionService,
    private _snack:MatSnackBar,
    private router:Router,


  ) { }

  ngOnInit(): void {
    var user = localStorage.getItem('currentUser');
    this.userObject = user != null ? JSON.parse(user) : this.userObject;

    this.qId=this._route.snapshot.params['qid'];
    this.qTitle=this._route.snapshot.params['title'];
    this._question.getQuestionOfQuiz(this.qId).subscribe((data:any)=>{
      this.question=data;
      console.log(data);
    },
    (error)=>{
      console.log(error);
    });
    
  }

  deleteQuestion(qId:any){
  this._question.deleteQuestion(qId).subscribe((data:any)=>{
    this._snack.open('Success !! Question is deleted','',{
      duration:3000,
    });
    (error: any)=>{
      console.log(error);
      this._snack.open('Error in deleting question!!','',{
        duration:3000
      })
    }
  });


}
addQuestions(qid:any, qTitle:any){
 
  if(this.userObject.role.roleName == 'ADMIN'){
  this.router.navigate(['/admin/add-question/'+ qid +'/' + qTitle])
} else {
  this.router.navigate(['/examiner/add-question/'+ qid +'/' + qTitle])
}
}
}
