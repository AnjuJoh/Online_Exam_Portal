import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { RoleService } from 'src/app/services/role.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  user =
    {
      userName: '',
      password: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      role: {
        roleName: '',
        id: ''
      }
    };

  roles = [{
    roleName: '',
    id: ''
  }]

  id = 0;

  constructor(private _route: ActivatedRoute, private userService: UserService, private roleService: RoleService, private _snack: MatSnackBar, private router: Router) { }

  ngOnInit(): void {
    this.id = this._route.snapshot.params['id'];
    console.log('this.id', this.id)

    if (this.id != undefined) {

      this.userService.getUser(this.id).subscribe(
        (data: any) => {
          this.user = data;
          console.log(this.user);
          console.log(this.user.lastName);
        },
        (error) => {
          console.log(error);

          //   this._snack.open("Something went wrong",'',{
          //     duration:3000
          //   });
          // }

        }
      );
    }

    this.roleService.getAllRoles().subscribe(
      (data: any) => {
        this.roles = data;
        console.log(this.roles);
        // console.log(this.user.lastName);
      },
      (error) => {
        console.log(error);

        //   this._snack.open("Something went wrong",'',{
        //     duration:3000
        //   });
        // }

      }
    );
  }

  updateUser() {
    this.userService.updateUser(this.user).subscribe(
      (data: any) => {
        this.user = data;
        console.log(this.user);
        console.log(this.user.lastName);
        this.router.navigate(['admin/user']);
      },
      (error) => {
        console.log(error);

        this._snack.open("Failed to Update User", '', {
          duration: 30
        });
      }


    );
  }

  addUser() {
    this.userService.registerUser(this.user).subscribe(
      (data: any) => {
        this.user = data;
        console.log(this.user);
        console.log(this.user.lastName);
        this.router.navigate(['admin/user']);
      },
      (error) => {
        console.log(error);

        this._snack.open("Failed to Create New User", '', {
          duration: 30
        });
      }


    );
  }

}
