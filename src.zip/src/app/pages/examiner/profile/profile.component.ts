import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  userObject =
  {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: {
      roleName: '',
      id: '',
    }
  } ;
  loggedIn: any;

  constructor() { }

  ngOnInit(): void {
    var user = localStorage.getItem('currentUser');
   this.userObject = user != null ? JSON.parse(user) : this.userObject;
  //  if (user != '') {
  //   this.loggedIn = true;
  // } else {
  //   this.loggedIn = false;
  
  // }
  
  }

}
