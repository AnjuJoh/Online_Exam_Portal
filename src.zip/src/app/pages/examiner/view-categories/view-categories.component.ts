import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { SwipeableDrawer } from '@mui/material';
import { switchAll } from 'rxjs';
import { CategoryService } from 'src/app/services/category.service';

@Component({
  selector: 'app-view-categories',
  templateUrl: './view-categories.component.html',
  styleUrls: ['./view-categories.component.css']
})
export class ViewCategoriesComponent implements OnInit {

  categories=[
   
      {
        title:'',
        description:'',
      }
      
     
  ];

  userObject =
  {
    userName: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: {
      roleName: '',
      id: '',
    }
  } ;
  constructor(private _category: CategoryService,private router:Router) {}

  ngOnInit(): void {
   var user = localStorage.getItem('currentUser');
   this.userObject = user != null ? JSON.parse(user) : this.userObject;
   if (this.userObject.role.roleName == 'ADMIN') {

    this._category.categories().subscribe(
      (data: any) => {
        this.categories=data;
        console.log(this.categories);
      },
      (error)=> {
        console.log(error);
        return('error');
      }
      );
   } else {
    this._category.getCategoriesByUser(this.userObject).subscribe(
      (data: any) => {
        this.categories=data;
        console.log(this.categories);
      },
      (error)=> {
        console.log(error);
        return('error');
      }
      );
   }

    
  }
  routerLink="/examiner/add-category"
  addNewCategory(){
 
    if(this.userObject.role.roleName == 'ADMIN'){
    this.router.navigate(['/admin/add-category'])
  } else {
    this.router.navigate(['/examiner/add-category'])
  }
  }

}
