import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ExaminerComponent } from './pages/examiner/examiner.component';
import { ExaminerpanelComponent } from './pages/examiner/examinerpanel/examinerpanel.component';
import { LoginComponent } from './pages/login/login.component';
import { ProfileComponent } from './pages/examiner/profile/profile.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { ViewCategoriesComponent } from './pages/examiner/view-categories/view-categories.component';
import { AddCategoryComponent } from './pages/examiner/add-category/add-category.component';
import { ViewQuizzesComponent } from './pages/examiner/view-quizzes/view-quizzes.component';
import { AddQuizComponent } from './pages/examiner/add-quiz/add-quiz.component';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { UpdateQuizComponent } from './pages/examiner/update-quiz/update-quiz.component';
import { ViewQuizQuestionsComponent } from './pages/examiner/view-quiz-questions/view-quiz-questions.component';
import { AddQuestionComponent } from './pages/examiner/add-question/add-question.component';
import { UserComponent } from './pages/examiner/user/user.component';
import { UserDashboardComponent } from './pages/user/user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './pages/examiner/admin-dashboard/admin-dashboard.component';
import { ViewRoleComponent } from './pages/examiner/view-role/view-role.component';
import { AddRoleComponent } from './pages/examiner/add-role/add-role.component';
import { AddUserComponent } from './pages/examiner/add-user/add-user.component';
import { LoadQuizComponent } from './pages/user/load-quiz/load-quiz.component';
import { InstructionsComponent } from './pages/user/instructions/instructions.component';
import { StartComponent } from './pages/user/start/start.component';
import { NormalGuard } from './services/normal.guard';



const routes: Routes = [
  {
    path:'',
    component:HomeComponent,
    pathMatch:'full',
  },
  {
    path:'header',
    component:HeaderComponent,
    pathMatch:'full',
  },
  {
    path:'navbar',
    component:NavbarComponent,
    pathMatch:'full',
  },
  {
    path:'footer',
    component:FooterComponent,
    pathMatch:'full',
  },
  {
    path: 'registration',
    component: RegistrationComponent,
    pathMatch: 'full'
  },
  {
    path:'login',
    component:LoginComponent,
    pathMatch:'full'
  },
  {
    path:'admin',
    component: AdminDashboardComponent,
    pathMatch: 'full'
  },
  {
    path:'user-dashboard',
    component: UserDashboardComponent,
    canActivate: [NormalGuard],
    children:[
      {
        path:':catId',
        component:LoadQuizComponent,
      },
      {
        path:'instructions/:qId',
        component:InstructionsComponent,
      },
    

    ]
  },
  {
    path:'examiner',
    component:ExaminerComponent,
    
    children:[

      {
        path:'',
        component:ExaminerpanelComponent,
      },
      {
        path:'profile',
        component:ProfileComponent,

      },
      {
        path:'categories',
        component:ViewCategoriesComponent,
      },
      {
        path:'add-category',
        component:AddCategoryComponent,
      },
      {
        path:'quizzes',
        component:ViewQuizzesComponent,
      },
      {
        path:'add-quiz',
        component:AddQuizComponent,
      },
      {
        path:'quiz/:qid',
        component:UpdateQuizComponent,
      },
      {
        path:'view-questions/:qid/:title',
        component:ViewQuizQuestionsComponent,
      },
      {
        path:'add-question/:qid/:title',
        component:AddQuestionComponent
      },

    ]
  },
  {
    path:'admin',
    component:AdminDashboardComponent,
    
    children:[

      {
        path:'',
        component:ExaminerpanelComponent,
      },
      {
        path:'profile',
        component:ProfileComponent,

      },
      {
        path:'categories',
        component:ViewCategoriesComponent,
      },
      {
        path:'add-category',
        component:AddCategoryComponent,
      },
      {
        path:'quizzes',
        component:ViewQuizzesComponent,
      },
      {
        path:'add-quiz',
        component:AddQuizComponent,
      },
      {
        path:'quiz/:qid',
        component:UpdateQuizComponent,
      },
      {
        path:'view-questions/:qid/:title',
        component:ViewQuizQuestionsComponent,
      },
      {
        path:'add-question/:qid/:title',
        component:AddQuestionComponent
      },
      {
        path:'user',
        component: UserComponent
      },
      {
        path:'role',
        component: ViewRoleComponent
      },
      {
        path:'addUser/:id',
        component: AddUserComponent
      },
      {
        path:'addUser',
        component: AddUserComponent
      }, 
      {
        path:'addRole/:id',
        component: AddRoleComponent
      },
      {
        path:'addRole',
        component: AddRoleComponent
      }, 



    ]
  },
  {
    path:'start/:qId',
    component:StartComponent,
    canActivate: [NormalGuard],
  },
 
  // {
  //   path:'examiner',
  //   component:ExaminerComponent,
  // },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
